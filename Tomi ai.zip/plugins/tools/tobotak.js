/*═══════════════════════════════════════════════════════
 *  ⌬  YT NeoShiroko Labs
 *═══════════════════════════════════════════════════════
 *  🌐  Website     : https://www.neolabsofficial.my.id
 *  ⌨︎  Developer   : https://zass.cloud
 *  ▶︎  YouTube     : https://www.youtube.com/@zassci_desu
 *  ⚙︎  Panel Murah : pteroku-desu.zass.cloud
 *
 *  ⚠︎  Mohon untuk tidak menghapus watermark ini
 *═══════════════════ © 2025 Zass Desuta ─════════════════════
 */

const fs = require("fs")
const axios = require("axios")
const FormData = require("form-data")

let handler = async (m, { conn }) => {
  try {
    const quoted = m.quoted || m
    const mime = (quoted.msg || quoted).mimetype || ""
    if (!mime || !/image/.test(mime)) {
      return m.reply("❌ Kirim atau reply gambar dengan caption *.tobotak*")
    }

    m.reply(wait)

    // download media
    const mediaPath = await conn.downloadAndSaveMediaMessage(quoted)

    // upload ke CloudGood
    const form = new FormData()
    form.append("file", fs.createReadStream(mediaPath))
    const cloudRes = await axios.post("https://cloudgood.xyz/upload.php", form, {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    })

    const imageUrl = cloudRes.data?.url
    fs.unlinkSync(mediaPath)

    if (!imageUrl) return m.reply(eror)

    // kirim hasil botak
    await conn.sendMessage(
      m.chat,
      {
        image: {
          url: `https://api-faa-skuarta.vercel.app/faa/tobotak?url=${encodeURIComponent(imageUrl)}`,
        },
        caption: "Nih jadi botak 🧑‍🦲",
      },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    m.reply(`${eror}:\n${err.message}`)
  }
}

handler.help = ["tobotak"].map((a) => a + " *[reply/send media]*")
handler.tags = ["tools"]
handler.command = /^tobotak$/i
handler.limit = true

module.exports = handler