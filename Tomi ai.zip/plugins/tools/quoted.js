/*═══════════════════════════════════════════════════════
 *  ⌬  YT NeoShiroko Labs
 *═══════════════════════════════════════════════════════
 *  🌐  Website     : https://www.neolabsofficial.my.id
 *  ⌨︎  Developer   : https://zass.cloud
 *  ▶︎  YouTube     : https://www.youtube.com/@zassci_desu
 *  ⚙︎  Panel Murah : pteroku-desu.zass.cloud
 *
 *  ⚠︎  Mohon untuk tidak menghapus watermark ini
 *═══════════════════ © 2025 Zass Desuta ─════════════════════
 */

module.exports = {
  help: ["q", "quoted"],
  tags: ["tools"],
  command: ["q", "quoted"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!m.quoted)
      throw `*• Example :* ${usedPrefix + command} *[reply message]*`;
    let q = await m.getQuotedObj();
    if (q.quoted) {
      q.quoted.copyNForward(m.chat);
    } else return m.reply("*[ ! ]* Can't quoted this message");
  },
};
