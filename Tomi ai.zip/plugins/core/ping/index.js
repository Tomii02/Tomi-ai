module.exports = {
  name: "Ping Test",
  description: "Test koneksi bot dengan ping command",
  
  commands: {
    ping: async (ctx) => {
      const startTime = Date.now();
      const responseTime = Date.now() - startTime;
      
      const response = `🏓 **Pong!**
⏱️ Response: ${responseTime}ms
🔄 Uptime: ${Math.floor(process.uptime())}s
📱 Platform: ${ctx.chat.platform}
👤 User: ${ctx.chat.sender.name}`;

      ctx.reply(response);
    }
  },

  tools: {
    "ping.test": {
      description: "Test koneksi dan response time bot",
      schema: {
        type: "object",
        properties: {
          include_stats: {
            type: "boolean",
            description: "Include additional stats"
          }
        }
      },
      handler: async (ctx, input) => {
        const startTime = Date.now();
        const responseTime = Date.now() - startTime;
        
        return {
          success: true,
          response_time: responseTime,
          uptime: process.uptime(),
          platform: ctx.chat.platform,
          user: ctx.chat.sender.name,
          timestamp: new Date().toISOString()
        };
      }
    }
  }
};