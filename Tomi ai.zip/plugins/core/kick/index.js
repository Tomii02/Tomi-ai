module.exports = {
  name: "Group Kick",
  description: "Kick member dari grup WhatsApp",
  
  commands: {
    kick: async (ctx) => {
      // Cek admin privileges
      if (!ctx.chat.sender.isAdmin) {
        return ctx.reply("❌ Hanya admin yang bisa kick member!");
      }

      // Cek apakah di grup
      if (ctx.chat.channel !== 'group') {
        return ctx.reply("❌ Command ini hanya bisa dipakai di grup!");
      }

      try {
        let target, targetName;

        // 1. Cek mention
        if (ctx.mentions && ctx.mentions.length > 0) {
          target = ctx.mentions[0];
          targetName = target.split('@')[0];
        }
        // 2. Cek reply
        else if (ctx.quotedMessage && ctx.quotedMessage.sender) {
          target = ctx.quotedMessage.sender.id;
          targetName = ctx.quotedMessage.sender.name || target.split('@')[0];
        }
        // 3. Cek argument nomor
        else if (ctx.args[0]) {
          const phoneNumber = ctx.args[0].replace(/[^\d]/g, '');
          if (phoneNumber.length > 8) {
            target = phoneNumber + '@s.whatsapp.net';
            targetName = phoneNumber;
          }
        }
        
        if (!target) {
          return ctx.reply(`❌ Caranya kick user:
📝 .kick @mention
📝 .kick (reply ke pesan user)  
📝 .kick 628123456789`);
        }

        // Get alasan kick (optional)
        const reason = ctx.args.slice(1).join(' ') || 'Tidak disebutkan';

        // Execute kick
        const result = await ctx.removeParticipant(target);
        
        if (result.success) {
          ctx.reply(`✅ User ${targetName} berhasil dikeluarkan!
📝 Alasan: ${reason}
⏰ ${new Date().toLocaleString('id-ID')}`);
        } else {
          ctx.reply(`❌ Gagal kick user ${targetName}: ${result.error}`);
        }

      } catch (error) {
        console.error("Error in kick command:", error);
        ctx.reply("❌ Terjadi error saat kick user");
      }
    }
  },

  tools: {
    "group.kick": {
      description: "Kick member dari grup WhatsApp",
      schema: {
        type: "object",
        properties: {
          target: {
            type: "string",
            description: "User ID atau nomor yang akan di-kick"
          },
          reason: {
            type: "string", 
            description: "Alasan kick (opsional)"
          }
        },
        required: ["target"]
      },
      handler: async (ctx, input) => {
        try {
          console.log(`🔨 Kicking user ${input.target} from group ${ctx.chat.chatId}`);
          console.log(`📝 Reason: ${input.reason}`);
          
          const result = await ctx.removeParticipant(input.target);
          
          if (result.success) {
            return {
              success: true,
              message: `User ${input.target} berhasil di-kick`,
              reason: input.reason || "AI auto-kick",
              timestamp: new Date().toISOString()
            };
          } else {
            return {
              success: false,
              error: result.error || "Gagal kick user",
              target: input.target
            };
          }
        } catch (error) {
          console.error('❌ Kick tool error:', error);
          return {
            success: false,
            error: error.message,
            target: input.target
          };
        }
      }
    }
  }
};