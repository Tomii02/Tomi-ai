const axios = require('axios');
let handler = async (m, { text, usedPrefix, command, db, conn, prefix }) => {
  if (!text) {
    return m.reply(`Contoh: ${usedPrefix + command} 1000`);
  }

  const hdepo = `${text}`;
  const amount = parseInt(text, 10) + generateRandomNumber(150, 450);
  let trgt = m.sender;
  let sentMessage;

  try {

    const pay = await (await fetch(`https://linecloud.my.id/api/orkut/createpayment?apikey=Line&amount=${amount}&codeqr=${text}`)).json();
    if (!pay || !pay.result) throw new Error("Gagal mendapatkan detail pembayaran.");

    const expirationTime = new Date(pay.result.expirationTime);
    const timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
    const currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
    const expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
    const hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
    const minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
    const formattedTime = `${hours}:${minutes}`;

    const tek = `𝗗𝗘𝗧𝗔𝗜𝗟 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 📢
  
> 🆔 𝖨𝖣 𝖳𝗋𝗑 : ${pay.result.transactionId}
> 🏧 𝖳𝗈𝗍𝖺𝗅 𝖡𝖺𝗒𝖺𝗋 : ${pay.result.amount}
> 📦 𝖨𝗍𝖾𝗆 : Deposit Saldo
> ⏱️ 𝖶𝖺𝗄𝗍𝗎 : ${timeLeft} Menit

𝗜𝗡𝗙𝗢 : ⚠️

𝘘𝘳𝘪𝘴 𝘋𝘪 𝘈𝘵𝘢𝘴 𝘏𝘢𝘯𝘺𝘢 𝘉𝘦𝘳𝘭𝘢𝘬𝘶 𝘚𝘢𝘮𝘱𝘢𝘪 _${formattedTime}_, 𝘈𝘱𝘢𝘣𝘪𝘭𝘢 𝘚𝘶𝘥𝘢𝘩 𝘓𝘦𝘣𝘪𝘩 𝘋𝘢𝘳𝘪 _${formattedTime}_ 𝘔𝘢𝘬𝘢 𝘗𝘦𝘮𝘣𝘢𝘺𝘢𝘳𝘢𝘯 𝘚𝘶𝘥𝘢𝘩 𝘛𝘪𝘥𝘢𝘬 𝘉𝘦𝘳𝘭𝘢𝘬𝘶.`;

    sentMessage = await conn.sendMessage(
      m.chat,
      { image: { url: `${pay.result.qrImageUrl}` }, caption: `${tek}` },
      m
    );

    const apiUrl = `https://linecloud.my.id/api/orkut/cekstatus?apikey=Line&merchant=${pay.result.merchant}&keyorkut=${pay.result.keyorkut}`;
    let isTransactionComplete = false;

    const timer = setTimeout(async () => {
      if (!isTransactionComplete) {
        try {
          await conn.sendMessage(
            m.chat,
            {
              delete: {
                remoteJid: m.chat,
                fromMe: true,
                id: sentMessage.key.id,
              },
            }
          );
          await conn.sendMessage(m.chat, { text: 'Transaksi dibatalkan otomatis karena waktu pembayaran habis.' }, m);
        } catch (err) {
          console.error('Error menghapus pesan:', err);
        }
      }
    }, 5 * 60 * 1000);

    while (!isTransactionComplete) {
      try {
        const response = await axios.get(apiUrl);
        const result = response.data;
        console.log('Data transaksi:', result);
        
        if (result && result.amount && parseInt(result.amount) === parseInt(amount)) {
          isTransactionComplete = true;

          clearTimeout(timer);

          const notification = `🎉 Deposit Dengan ID ( ${pay.result.transactionId} ) Success 🎉`;
          await conn.sendMessage(m.chat, { text: notification }, m);
          
          addSaldo(trgt, parseInt(hdepo), db_saldo);

          m.reply(`💸Saldo Telah Masuk 💸

📌 Detail:

📞 Nomor: ${m.sender}
💰 Saldo Ditambahkan: Rp ${hdepo}

✨ Silakan ketik .saldo untuk melihat total saldo Anda saat ini. Terima kasih telah menggunakan layanan kami. Semoga hari Anda penuh keberuntungan! 🍀`);
        }
      } catch (error) {
        console.error('Error checking transaction status:', error);
      }

      if (!isTransactionComplete) {
        await new Promise(resolve => setTimeout(resolve, 10000)); 
      }
    }
  } catch (error) {
    console.error('Error creating QRIS or checking payment status:', error);
    m.reply('Gagal membuat atau memeriksa pembayaran.');
  }
};

handler.help = handler.command = ["deposit"];
handler.tags = ["store"];

module.exports = handler;

function generateRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
