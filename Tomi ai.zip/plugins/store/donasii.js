const axios = require('axios');
const crypto = require('crypto');

let handler = async (m, { text, conn }) => {
  if (!text) return m.reply('Mau DONASI Berapa Kak? Contoh .donasii 1000');

  // Global variables
  const apiKey = 'ZVtT0jLqKJDEM9e9My0zAyutcE0z3WCHjt2a0GO7';
  const privateKey = 'sqyHe-5yk7S-F6fIU-b4fZk-THGPW';
  const merchantCode = 'T24775';
  
  const merchantRef = 'RMHTOPUP' + randomNomor(1, 999999);
  const amount = `${text}`;
  const signature = crypto.createHmac('sha256', privateKey).update(merchantCode + merchantRef + amount).digest('hex');

  const data = {
    'method': 'QRIS2',
    'merchant_ref': merchantRef,
    'amount': amount,
    'customer_name': 'zass',
    'customer_email': 'pteroku@gmail.com',
    'order_items': [{
      'name': 'Bot WhatsApp ' + amount,
      'price': amount,
      'quantity': 1
    }],
    'return_url': `https://zass.cloud/donasi`,
    'signature': signature
  };

  try {
    const res = await axios.post('https://tripay.co.id/api/transaction/create', data, {
      headers: {
        'Authorization': 'Bearer ' + apiKey
      },
      validateStatus: function (status) {
        return status < 999;
      }
    });

    if (!res.data.success) {
      return m.reply(`${res.data.message}`);
    }

    if (res.data.data.status === 'UNPAID') {
      const message = `Silahkan Scan QRIS Untuk Donasi\n\nInformasi Donasi:\n\n=> ID Pembayaran: ${res.data.data.merchant_ref}\n=> Status: ${res.data.data.status}`;
      await conn.sendMessage(m.chat, { caption: message, image: { url: res.data.data.qr_url } });
    } else if (res.data.data.status === 'PAID') {
      const message = `*── 「 DONASI ${text} 」 ──*

_Silahkan Scan QRIS Ini Untuk Membayar:_
_=> No Trx: ${res.data.data.merchant_ref}_
_=> Total Donasi: Rp ${res.data.data.amount_received}_
_=> Fee: Rp ${res.data.data.total_fee}_
_=> Total: Rp ${res.data.data.amount}_
_=> Pembayaran: QRIS Otomatis_
_=> Status: ${res.data.data.status === 'PAID' ? 'Berhasil ✅' : 'Pending 😕'}_

Terima Kasih Telah Donasi.`;
      await conn.sendMessage(m.chat, { caption: message, image: { url: res.data.data.qr_url } });
    }
  } catch (error) {
    console.error('Error processing donation:', error);
    m.reply('Terjadi kesalahan saat memproses donasi.');
  }
};

handler.command = ['donasii'];
handler.help = ['donasii'];
handler.tags = ['donasii'];

module.exports = handler;

function randomNomor(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}