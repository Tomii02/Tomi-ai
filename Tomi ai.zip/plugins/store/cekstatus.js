const axios = require('axios');

let handler = async (m, { text, usedPrefix, command }) => {
  // Mengecek apakah input merchant dan keyorkut diberikan
  const [merchant, keyorkut] = text.split(' ');
  if (!merchant || !keyorkut) {
    return m.reply(`Contoh: ${usedPrefix + command} <merchant> <keyorkut>`);
  }

  const apikey = "Line";

  try {
    const response = await axios.get(`https://linecloud.my.id/api/orkut/cekstatus`, {
      params: {
        apikey,
        merchant,
        keyorkut
      }
    });

    const result = response.data;

    if (!result || !result.status) {
      throw new Error("Gagal memeriksa status deposit.");
    }

    const statusDetails = `
      𝗦𝗧𝗔𝗧𝗨𝗦 𝗗𝗘𝗣𝗢𝗦𝗜𝗧 📢
      🏧 Merchant: ${merchant}
      🧾 Key Orkut: ${keyorkut}
      📋 Status: ${result.status}
      💰 Amount: Rp ${result.amount || 'N/A'}
    `;

    m.reply(statusDetails);

  } catch (error) {
    console.error('Error checking deposit status:', error);
    m.reply('Gagal memeriksa status deposit.');
  }
};

handler.help = handler.command = ["cekstatus"];
handler.tags = ["payment"];

module.exports = handler;